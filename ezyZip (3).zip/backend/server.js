require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const { run, all, get } = require('./db');
const { initTwilio, sendOrderConfirmation, sendReservationConfirmation } = require('./sms');
const { initEmail, sendOrderConfirmationEmail, sendReservationConfirmationEmail } = require('./email');
const crypto = require('crypto');
const Razorpay = require('razorpay');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Initialize Twilio SMS
initTwilio();

// Initialize Email
initEmail();

let rzp = null;
function initRazorpay() {
  const keyId = process.env.RZP_KEY_ID;
  const keySecret = process.env.RZP_KEY_SECRET;
  if (keyId && keySecret) {
    rzp = new Razorpay({ key_id: keyId, key_secret: keySecret });
    console.log('[RAZORPAY] initialized');
  } else {
    console.log('[RAZORPAY] keys missing in .env');
  }
}
initRazorpay();

app.get('/api/menu', async (req, res) => {
  try {
    const items = await all('SELECT * FROM menu ORDER BY id');
    res.json(items);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/orders', async (req, res) => {
  try {
    const { items = [], customer = {}, total = 0, paymentMethod = 'cash' } = req.body;
    const result = await run(
      'INSERT INTO orders (customer_name, customer_email, customer_phone, total, status, created_at) VALUES (?,?,?,?,?,datetime("now"))',
      [customer.name || '', customer.email || '', customer.phone || '', total, 'pending']
    );
    const orderId = result.lastID;

    // Get menu items to fetch names and prices
    const itemsList = [];
    for (const it of items) {
      const menuItem = await get('SELECT * FROM menu WHERE id = ?', [it.id]);
      if (menuItem) {
        itemsList.push({
          id: it.id,
          name: menuItem.name,
          quantity: it.qty,
          price: menuItem.price
        });
        await run('INSERT INTO order_items (order_id, menu_id, quantity, price) VALUES (?,?,?,?)', [orderId, it.id, it.qty, menuItem.price]);
      }
    }

    // If online payment requested, create Razorpay order
    if (paymentMethod === 'online') {
      if (!rzp) return res.status(500).json({ error: 'Razorpay not configured on server' });
      const razorOrder = await rzp.orders.create({
        amount: Math.round(total * 100), // Convert to paise
        currency: 'INR',
        receipt: `order_${orderId}`,
        notes: { type: 'order', orderId: String(orderId) }
      });
      return res.json({ orderId, payment: { key: process.env.RZP_KEY_ID, order: razorOrder } });
    }

    // Send SMS confirmation if phone is provided
    if (customer.phone) {
      sendOrderConfirmation(customer.phone, orderId, total).catch(err => console.error('SMS send error:', err));
    }

    // Send email confirmation if email is provided
    if (customer.email) {
      sendOrderConfirmationEmail(customer.email, orderId, customer.name || 'Customer', total, itemsList).catch(err => console.error('Email send error:', err));
    }

    res.json({ orderId, status: 'confirmed' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/orders', async (req, res) => {
  try {
    const orders = await all('SELECT * FROM orders ORDER BY created_at DESC');
    for (const ord of orders) {
      ord.items = await all('SELECT oi.*, m.name FROM order_items oi LEFT JOIN menu m ON oi.menu_id = m.id WHERE oi.order_id = ?', [ord.id]);
    }
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/reservations', async (req, res) => {
  try {
    const { name, email, phone, date, time, party = 1, paymentMethod = 'cash' } = req.body;

    // create reservation row; use party_size column (fixes SQLITE_ERROR: no column named party)
    const result = await run(
      'INSERT INTO reservations (name, email, phone, date, time, party_size, status, created_at) VALUES (?,?,?,?,?,?,?,datetime("now"))',
      [name||'', email||'', phone||'', date||'', time||'', Number(party)||1, paymentMethod === 'online' ? 'pending_payment' : 'confirmed']
    );
    const reservationId = result && result.lastID ? result.lastID : (await get('SELECT last_insert_rowid() as id')).id;

    // if client requested online payment create Razorpay order for ₹100
    if (paymentMethod === 'online') {
      if (!rzp) return res.status(500).json({ error: 'Razorpay not configured on server' });
      const amountINR = 100;
      const razorOrder = await rzp.orders.create({
        amount: amountINR * 100,
        currency: 'INR',
        receipt: `reservation_${reservationId}`,
        notes: { type: 'reservation', reservationId: String(reservationId) }
      });
      return res.json({ reservationId, payment: { key: process.env.RZP_KEY_ID, order: razorOrder } });
    }

    // cash/reservation confirmed
    res.json({ reservationId, status: 'confirmed' });
  } catch (err) {
    console.error('POST /api/reservations error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Add verification endpoint (client calls this after successful Razorpay checkout)
app.post('/api/payments/verify', async (req, res) => {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature, type, id } = req.body;
    if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
      return res.status(400).json({ error: 'Missing verification fields' });
    }

    const generated = crypto.createHmac('sha256', process.env.RZP_KEY_SECRET)
      .update(razorpay_order_id + '|' + razorpay_payment_id)
      .digest('hex');

    if (generated !== razorpay_signature) {
      return res.status(400).json({ success: false, error: 'Invalid signature' });
    }

    if (type === 'reservation') {
      const rid = Number(id);
      const res_data = await get('SELECT * FROM reservations WHERE id = ?', [rid]);
      await run('UPDATE reservations SET status = ?, payment_id = ? WHERE id = ?', ['paid', razorpay_payment_id, rid]);
      
      // Send confirmation email for paid reservation
      if (res_data && res_data.email) {
        sendReservationConfirmationEmail(res_data.email, rid, res_data.name || 'Guest', res_data.date, res_data.time, res_data.party_size).catch(err => console.error('Email send error:', err));
      }
      return res.json({ success: true, type, id: rid });
    }

    if (type === 'order') {
      const oid = Number(id);
      const order_data = await get('SELECT * FROM orders WHERE id = ?', [oid]);
      await run('UPDATE orders SET status = ?, payment_id = ? WHERE id = ?', ['paid', razorpay_payment_id, oid]);
      
      // Send confirmation email for paid order
      if (order_data && order_data.customer_email) {
        const items = await all('SELECT oi.*, m.name, m.price as menu_price FROM order_items oi LEFT JOIN menu m ON oi.menu_id = m.id WHERE oi.order_id = ?', [oid]);
        console.log('[PAYMENT VERIFY] Order', oid, 'items found:', items.length, 'items:', items);
        const itemsList = items.map(i => ({ 
          name: i.name || 'Item', 
          quantity: i.quantity, 
          price: i.price || i.menu_price 
        }));
        console.log('[PAYMENT VERIFY] itemsList:', itemsList);
        sendOrderConfirmationEmail(order_data.customer_email, oid, order_data.customer_name || 'Customer', order_data.total, itemsList).catch(err => console.error('Email send error:', err));
      }
      return res.json({ success: true, type, id: oid });
    }

    // unknown type -> acknowledge verified
    return res.json({ success: true, note: 'verified' });
  } catch (err) {
    console.error('/api/payments/verify error:', err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/reservations', async (req, res) => {
  try {
    const rows = await all('SELECT * FROM reservations ORDER BY created_at DESC');
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Feedback endpoints
app.post('/api/feedback', async (req, res) => {
  try {
    const { name, email, phone, rating = 5, comment = '' } = req.body;
    const result = await run('INSERT INTO feedback (name, email, phone, rating, comment, created_at) VALUES (?,?,?,?,?,datetime("now"))', [name, email, phone, rating, comment]);
    res.json({ feedbackId: result.lastID });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/feedback', async (req, res) => {
  try {
    const rows = await all('SELECT * FROM feedback ORDER BY created_at DESC');
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/admin/feedback', async (req, res) => {
  try {
    const rows = await all('SELECT * FROM feedback ORDER BY created_at DESC');
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Admin endpoints: enriched views with payment info
app.get('/api/admin/reservations', async (req, res) => {
  try {
    const rows = await all('SELECT * FROM reservations ORDER BY created_at DESC');
    const out = [];
    for (const r of rows) {
      let paid = false;
      let payment_ref = null;
      let payment_details = null;
      
      // Check if payment_id exists (from Razorpay)
      if (r.payment_id) {
        paid = true;
        payment_ref = r.payment_id;
      }
      
      // Also check payments table
      const pay = await get('SELECT id, status, details FROM payments WHERE reservation_id = ? ORDER BY created_at DESC LIMIT 1', [r.id]);
      if (pay) {
        payment_ref = pay.id;
        paid = pay.status === 'completed' || pay.status === 'paid';
        try { payment_details = JSON.parse(pay.details || '{}'); } catch(e) { payment_details = pay.details; }
      }
      
      out.push({
        id: r.id,
        name: r.name,
        phone: r.phone,
        email: r.email,
        date: r.date,
        time: r.time,
        party_size: r.party_size,
        status: r.status,
        created_at: r.created_at,
        paid,
        payment_ref,
        payment_details
      });
    }
    res.json(out);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/admin/orders', async (req, res) => {
  try {
    const rows = await all('SELECT * FROM orders ORDER BY created_at DESC');
    const out = [];
    for (const o of rows) {
      const items = await all('SELECT oi.*, m.name FROM order_items oi LEFT JOIN menu m ON oi.menu_id = m.id WHERE oi.order_id = ?', [o.id]);
      let paid = false;
      let payment_ref = null;
      let payment_details = null;
      
      // Check if payment_id exists (from Razorpay)
      if (o.payment_id) {
        paid = true;
        payment_ref = o.payment_id;
      }
      
      // Also check payments table
      const pay = await get('SELECT id, status, details FROM payments WHERE order_id = ? ORDER BY created_at DESC LIMIT 1', [o.id]);
      if (pay) {
        payment_ref = pay.id;
        paid = pay.status === 'completed' || pay.status === 'paid';
        try { payment_details = JSON.parse(pay.details || '{}'); } catch(e) { payment_details = pay.details; }
      }
      
      out.push({
        id: o.id,
        name: o.customer_name,
        phone: o.customer_phone,
        email: o.customer_email,
        total: o.total,
        status: o.status,
        created_at: o.created_at,
        items,
        paid,
        payment_ref,
        payment_details
      });
    }
    res.json(out);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/payments', async (req, res) => {
  try {
    const { orderId = null, reservationId = null, amount = 0, method = 'card', details = {} } = req.body;
    const result = await run(
      'INSERT INTO payments (order_id, reservation_id, amount, method, status, details, created_at) VALUES (?,?,?,?,?,?,datetime("now"))',
      [orderId, reservationId, amount, method, 'completed', JSON.stringify(details || {})]
    );

    if (orderId) await run('UPDATE orders SET status = ? WHERE id = ?', ['paid', orderId]);
    if (reservationId) await run('UPDATE reservations SET status = ? WHERE id = ?', ['confirmed', reservationId]);

    res.json({ paymentId: result.lastID });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Optionally serve frontend files from parent folder
app.use(express.static(path.join(__dirname, '..')));

// For any API route not matched above, return JSON 404 instead of HTML
app.use('/api', (req, res) => {
  res.status(404).json({ error: 'API endpoint not found' });
});

// Global error handler that always returns JSON
app.use((err, req, res, next) => {
  console.error('Unhandled server error:', err);
  if (res.headersSent) return next(err);
  res.status(500).json({ error: err && err.message ? err.message : 'Internal server error' });
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
